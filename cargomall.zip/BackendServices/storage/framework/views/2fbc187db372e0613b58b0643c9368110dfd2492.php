แจ้งการชำระค่าบริการนำเข้าสินค้า

<br>
<h3 style="color : #C91313;">สถานะ : ชำระเงินค่าขนส่งแล้ว</h3>
<br>
หมายเลข tracking : <?php echo e($importer->tracking_no); ?>

<br>
ผู้ชำระ <?php echo e($importer->customer->firstname); ?> <?php echo e($importer->customer->lastname); ?>

<br>
วันที่ชำระ <?php echo e($pay->created_at); ?>

<br>
จำนวนเงินที่ชำระ : <?php echo e($pay->pay_amount_thb); ?> บาท
<br><br>
ยอดเงินคงเหลือในหระเป๋าของคุณคือ <?php echo e($money_bag->balance); ?> บาท

<?php $__env->startComponent('mail::button', ['url' => 'http://aomkuma.com/importer' ]); ?>
ท่านสามารถตรวจสอบสถานะสินค้าได้ที่นี่
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?><?php /**PATH C:\xampp7\htdocs\cargomall\web\BackendServices\resources\views/emails/importer/cost.blade.php ENDPATH**/ ?>