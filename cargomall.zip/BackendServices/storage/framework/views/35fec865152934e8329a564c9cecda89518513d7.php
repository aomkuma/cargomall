แจ้งผลการโอนเงิน

<br>
<h3 style="color : #C91313;">สถานะ : <?php echo e($transfer->pay_status == 2?'อนุมัติการโอนเงิน (สำเร็จ)':'ปฏิเสธการโอนเงิน'); ?></h3>
<br>

<?php if($transfer->pay_status == 2): ?>
ยอดเงินถูกโอนเข้าบัญชีธนาคารจีนชื่อ : <?php echo e($transfer->payer_name); ?>

<br>
จำนวนเงินที่โอน : <?php echo e($transfer->pay_amount_yuan); ?> หยวน
<br>
เรทโอนเงิน (ต่อ 1 หยวน) : <?php echo e($transfer->exchange_rate); ?> บาท
<br>
จำนวนเงินที่ถูกหักจากกระเป๋าเงินของคุณ : <?php echo e($transfer->pay_amount_thb); ?> บาท
<br><br>
<?php endif; ?>

ยอดเงินคงเหลือในกระเป๋าของคุณคือ <?php echo e($money_bag->balance); ?> บาท
<br>
Thanks,<br>
<?php echo e(config('app.name')); ?><?php /**PATH C:\xampp7\htdocs\cargomall\web\BackendServices\resources\views/emails/notification/transfer.blade.php ENDPATH**/ ?>