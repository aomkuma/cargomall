แจ้งผลการฝากจ่าย

<br>
<h3 style="color : #C91313;">สถานะ : <?php echo e($deposit->pay_status == 2?'ยืนยันการฝากจ่าย (สำเร็จ)':'ยกเลิกการฝากจ่าย'); ?></h3>
<br>

<?php if($deposit->pay_status == 2): ?>
จ่ายไปยังเลขที่ order : <?php echo e($deposit->order_no); ?>

<br>
จำนวนเงินที่ฝากจ่าย : <?php echo e($deposit->pay_amount_yuan); ?> หยวน
<br>
เรทฝากจ่าย (ต่อ 1 หยวน) : <?php echo e($deposit->exchange_rate); ?> บาท
<br>
จำนวนเงินที่ถูกหักจากกระเป๋าเงินของคุณ : <?php echo e($deposit->pay_amount_thb); ?> บาท
<br><br>
<?php endif; ?>

ยอดเงินคงเหลือในกระเป๋าของคุณคือ <?php echo e($money_bag->balance); ?> บาท
<br>
Thanks,<br>
<?php echo e(config('app.name')); ?><?php /**PATH C:\xampp7\htdocs\cargomall\web\BackendServices\resources\views/emails/notification/deposit.blade.php ENDPATH**/ ?>