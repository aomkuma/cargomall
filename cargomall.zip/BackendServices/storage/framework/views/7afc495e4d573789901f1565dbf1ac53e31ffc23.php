<h3>เรียนคุณ <?php echo e($email_data['firstname']); ?> <?php echo e($email_data['lastname']); ?></h3>
<br>แจ้ง URL สำหรับการรีเซ็ตรหัสผ่านใหม่ สำหรับอีเมล <?php echo e($email_data['email']); ?> คือ 
<br>
<?php echo e($email_data['url']); ?>

<br>
<br>
Thanks,<br>
<?php echo e(config('app.name')); ?><?php /**PATH C:\xampp7\htdocs\cargomall\BackendServices\resources\views/emails/notification/forgotpassword.blade.php ENDPATH**/ ?>