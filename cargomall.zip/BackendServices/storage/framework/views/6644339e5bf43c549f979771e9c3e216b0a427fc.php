แจ้งผลการเติมเงิน

<br>
<h3 style="color : #C91313;">สถานะ : <?php echo e($topup->topup_status == 2?'อนุมัติการเติมเงิน':'ปฏิเสธการเติมเงิน'); ?></h3>
<br>

<?php if($topup->topup_status == 2): ?>
ยอดเงินเข้ากระเป๋าของคุณ : <?php echo e($topup->customer->firstname); ?> <?php echo e($topup->customer->lastname); ?>

<br>
จำนวนเงินที่เติม : <?php echo e($topup->topup_amount); ?> บาท
<br><br>
<?php endif; ?>

ยอดเงินคงเหลือในกระเป๋าของคุณคือ <?php echo e($money_bag->balance); ?> บาท
<br>
Thanks,<br>
<?php echo e(config('app.name')); ?><?php /**PATH C:\xampp7\htdocs\cargomall\web\BackendServices\resources\views/emails/notification/topup.blade.php ENDPATH**/ ?>