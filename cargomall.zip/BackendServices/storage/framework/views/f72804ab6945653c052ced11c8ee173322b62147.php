<?php echo e($slot); ?>

<?php /**PATH C:\xampp7\htdocs\cargomall\web\BackendServices\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>