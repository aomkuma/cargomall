<?php
return [
    'google_translate_api_key'=>'AIzaSyCIQ0NJYS09Gp3lJdpR4gsmS9QQ5xPs_fU',
    'trans_functions' => [
        'trans',
        'trans_choice',
        'Lang::get',
        'Lang::choice',
        'Lang::trans',
        'Lang::transChoice',
        '@lang',
        '@choice',
        '__',
        '\$trans.get',
        '\$t'
    ],
];
